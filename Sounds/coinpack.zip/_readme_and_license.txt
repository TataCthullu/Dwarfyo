Pack downloaded from Freesound
----------------------------------------

"Coins Sound Library"

This Pack of sounds contains sounds by the following user:
 - LittleRobotSoundFactory ( https://freesound.org/people/LittleRobotSoundFactory/ )

You can find this pack online at: https://freesound.org/people/LittleRobotSoundFactory/packs/17044/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this Pack
-------------------

  * 276237__littlerobotsoundfactory__coins_pouring_04.wav.wav
    * url: https://freesound.org/s/276237/
    * license: Attribution 4.0
  * 276236__littlerobotsoundfactory__coins_pouring_05.wav.wav
    * url: https://freesound.org/s/276236/
    * license: Attribution 4.0
  * 276235__littlerobotsoundfactory__coins_pouring_06.wav.wav
    * url: https://freesound.org/s/276235/
    * license: Attribution 4.0
  * 276234__littlerobotsoundfactory__coins_pouring_07.wav.wav
    * url: https://freesound.org/s/276234/
    * license: Attribution 4.0
  * 276233__littlerobotsoundfactory__coins_pouring_08.wav.wav
    * url: https://freesound.org/s/276233/
    * license: Attribution 4.0
  * 276232__littlerobotsoundfactory__coins_pouring_09.wav.wav
    * url: https://freesound.org/s/276232/
    * license: Attribution 4.0
  * 276231__littlerobotsoundfactory__coins_pouring_10.wav.wav
    * url: https://freesound.org/s/276231/
    * license: Attribution 4.0
  * 276230__littlerobotsoundfactory__coins_pouring_11.wav.wav
    * url: https://freesound.org/s/276230/
    * license: Attribution 4.0
  * 276229__littlerobotsoundfactory__coins_pouring_12.wav.wav
    * url: https://freesound.org/s/276229/
    * license: Attribution 4.0
  * 276228__littlerobotsoundfactory__coins_pouring_13.wav.wav
    * url: https://freesound.org/s/276228/
    * license: Attribution 4.0
  * 276227__littlerobotsoundfactory__coins_single_24.wav.wav
    * url: https://freesound.org/s/276227/
    * license: Attribution 4.0
  * 276226__littlerobotsoundfactory__coins_single_23.wav.wav
    * url: https://freesound.org/s/276226/
    * license: Attribution 4.0
  * 276225__littlerobotsoundfactory__coins_single_22.wav.wav
    * url: https://freesound.org/s/276225/
    * license: Attribution 4.0
  * 276224__littlerobotsoundfactory__coins_single_21.wav.wav
    * url: https://freesound.org/s/276224/
    * license: Attribution 4.0
  * 276223__littlerobotsoundfactory__coins_single_20.wav.wav
    * url: https://freesound.org/s/276223/
    * license: Attribution 4.0
  * 276222__littlerobotsoundfactory__coins_single_19.wav.wav
    * url: https://freesound.org/s/276222/
    * license: Attribution 4.0
  * 276221__littlerobotsoundfactory__coins_single_18.wav.wav
    * url: https://freesound.org/s/276221/
    * license: Attribution 4.0
  * 276220__littlerobotsoundfactory__coins_single_17.wav.wav
    * url: https://freesound.org/s/276220/
    * license: Attribution 4.0
  * 276219__littlerobotsoundfactory__coins_single_26.wav.wav
    * url: https://freesound.org/s/276219/
    * license: Attribution 4.0
  * 276218__littlerobotsoundfactory__coins_single_25.wav.wav
    * url: https://freesound.org/s/276218/
    * license: Attribution 4.0
  * 276217__littlerobotsoundfactory__coins_pouring_03.wav.wav
    * url: https://freesound.org/s/276217/
    * license: Attribution 4.0
  * 276216__littlerobotsoundfactory__coins_pouring_02.wav.wav
    * url: https://freesound.org/s/276216/
    * license: Attribution 4.0
  * 276215__littlerobotsoundfactory__coins_pouring_01.wav.wav
    * url: https://freesound.org/s/276215/
    * license: Attribution 4.0
  * 276214__littlerobotsoundfactory__coins_pouring_00.wav.wav
    * url: https://freesound.org/s/276214/
    * license: Attribution 4.0
  * 276213__littlerobotsoundfactory__coins_few_45.wav.wav
    * url: https://freesound.org/s/276213/
    * license: Attribution 4.0
  * 276212__littlerobotsoundfactory__coins_few_44.wav.wav
    * url: https://freesound.org/s/276212/
    * license: Attribution 4.0
  * 276211__littlerobotsoundfactory__coins_few_43.wav.wav
    * url: https://freesound.org/s/276211/
    * license: Attribution 4.0
  * 276210__littlerobotsoundfactory__coins_few_42.wav.wav
    * url: https://freesound.org/s/276210/
    * license: Attribution 4.0
  * 276209__littlerobotsoundfactory__coins_few_41.wav.wav
    * url: https://freesound.org/s/276209/
    * license: Attribution 4.0
  * 276208__littlerobotsoundfactory__coins_few_40.wav.wav
    * url: https://freesound.org/s/276208/
    * license: Attribution 4.0
  * 276207__littlerobotsoundfactory__coins_single_31.wav.wav
    * url: https://freesound.org/s/276207/
    * license: Attribution 4.0
  * 276206__littlerobotsoundfactory__coins_single_32.wav.wav
    * url: https://freesound.org/s/276206/
    * license: Attribution 4.0
  * 276205__littlerobotsoundfactory__coins_single_33.wav.wav
    * url: https://freesound.org/s/276205/
    * license: Attribution 4.0
  * 276204__littlerobotsoundfactory__coins_single_34.wav.wav
    * url: https://freesound.org/s/276204/
    * license: Attribution 4.0
  * 276203__littlerobotsoundfactory__coins_single_27.wav.wav
    * url: https://freesound.org/s/276203/
    * license: Attribution 4.0
  * 276202__littlerobotsoundfactory__coins_single_28.wav.wav
    * url: https://freesound.org/s/276202/
    * license: Attribution 4.0
  * 276201__littlerobotsoundfactory__coins_single_29.wav.wav
    * url: https://freesound.org/s/276201/
    * license: Attribution 4.0
  * 276200__littlerobotsoundfactory__coins_single_30.wav.wav
    * url: https://freesound.org/s/276200/
    * license: Attribution 4.0
  * 276199__littlerobotsoundfactory__coins_single_35.wav.wav
    * url: https://freesound.org/s/276199/
    * license: Attribution 4.0
  * 276198__littlerobotsoundfactory__coins_single_36.wav.wav
    * url: https://freesound.org/s/276198/
    * license: Attribution 4.0
  * 276197__littlerobotsoundfactory__coins_several_18.wav.wav
    * url: https://freesound.org/s/276197/
    * license: Attribution 4.0
  * 276196__littlerobotsoundfactory__coins_several_19.wav.wav
    * url: https://freesound.org/s/276196/
    * license: Attribution 4.0
  * 276195__littlerobotsoundfactory__coins_several_12.wav.wav
    * url: https://freesound.org/s/276195/
    * license: Attribution 4.0
  * 276194__littlerobotsoundfactory__coins_several_13.wav.wav
    * url: https://freesound.org/s/276194/
    * license: Attribution 4.0
  * 276193__littlerobotsoundfactory__coins_several_10.wav.wav
    * url: https://freesound.org/s/276193/
    * license: Attribution 4.0
  * 276192__littlerobotsoundfactory__coins_several_11.wav.wav
    * url: https://freesound.org/s/276192/
    * license: Attribution 4.0
  * 276191__littlerobotsoundfactory__coins_several_16.wav.wav
    * url: https://freesound.org/s/276191/
    * license: Attribution 4.0
  * 276190__littlerobotsoundfactory__coins_several_17.wav.wav
    * url: https://freesound.org/s/276190/
    * license: Attribution 4.0
  * 276189__littlerobotsoundfactory__coins_several_14.wav.wav
    * url: https://freesound.org/s/276189/
    * license: Attribution 4.0
  * 276188__littlerobotsoundfactory__coins_several_15.wav.wav
    * url: https://freesound.org/s/276188/
    * license: Attribution 4.0
  * 276187__littlerobotsoundfactory__coins_several_09.wav.wav
    * url: https://freesound.org/s/276187/
    * license: Attribution 4.0
  * 276186__littlerobotsoundfactory__coins_several_08.wav.wav
    * url: https://freesound.org/s/276186/
    * license: Attribution 4.0
  * 276185__littlerobotsoundfactory__coins_several_01.wav.wav
    * url: https://freesound.org/s/276185/
    * license: Attribution 4.0
  * 276184__littlerobotsoundfactory__coins_several_00.wav.wav
    * url: https://freesound.org/s/276184/
    * license: Attribution 4.0
  * 276183__littlerobotsoundfactory__coins_several_03.wav.wav
    * url: https://freesound.org/s/276183/
    * license: Attribution 4.0
  * 276182__littlerobotsoundfactory__coins_several_02.wav.wav
    * url: https://freesound.org/s/276182/
    * license: Attribution 4.0
  * 276181__littlerobotsoundfactory__coins_several_05.wav.wav
    * url: https://freesound.org/s/276181/
    * license: Attribution 4.0
  * 276180__littlerobotsoundfactory__coins_several_04.wav.wav
    * url: https://freesound.org/s/276180/
    * license: Attribution 4.0
  * 276179__littlerobotsoundfactory__coins_several_07.wav.wav
    * url: https://freesound.org/s/276179/
    * license: Attribution 4.0
  * 276178__littlerobotsoundfactory__coins_several_06.wav.wav
    * url: https://freesound.org/s/276178/
    * license: Attribution 4.0
  * 276177__littlerobotsoundfactory__coins_few_08.wav.wav
    * url: https://freesound.org/s/276177/
    * license: Attribution 4.0
  * 276176__littlerobotsoundfactory__coins_few_09.wav.wav
    * url: https://freesound.org/s/276176/
    * license: Attribution 4.0
  * 276175__littlerobotsoundfactory__coins_few_04.wav.wav
    * url: https://freesound.org/s/276175/
    * license: Attribution 4.0
  * 276174__littlerobotsoundfactory__coins_few_05.wav.wav
    * url: https://freesound.org/s/276174/
    * license: Attribution 4.0
  * 276173__littlerobotsoundfactory__coins_few_06.wav.wav
    * url: https://freesound.org/s/276173/
    * license: Attribution 4.0
  * 276172__littlerobotsoundfactory__coins_few_07.wav.wav
    * url: https://freesound.org/s/276172/
    * license: Attribution 4.0
  * 276171__littlerobotsoundfactory__coins_few_00.wav.wav
    * url: https://freesound.org/s/276171/
    * license: Attribution 4.0
  * 276170__littlerobotsoundfactory__coins_few_01.wav.wav
    * url: https://freesound.org/s/276170/
    * license: Attribution 4.0
  * 276169__littlerobotsoundfactory__coins_few_02.wav.wav
    * url: https://freesound.org/s/276169/
    * license: Attribution 4.0
  * 276168__littlerobotsoundfactory__coins_few_03.wav.wav
    * url: https://freesound.org/s/276168/
    * license: Attribution 4.0
  * 276167__littlerobotsoundfactory__coins_few_18.wav.wav
    * url: https://freesound.org/s/276167/
    * license: Attribution 4.0
  * 276166__littlerobotsoundfactory__coins_few_19.wav.wav
    * url: https://freesound.org/s/276166/
    * license: Attribution 4.0
  * 276165__littlerobotsoundfactory__coins_few_14.wav.wav
    * url: https://freesound.org/s/276165/
    * license: Attribution 4.0
  * 276164__littlerobotsoundfactory__coins_few_15.wav.wav
    * url: https://freesound.org/s/276164/
    * license: Attribution 4.0
  * 276163__littlerobotsoundfactory__coins_few_16.wav.wav
    * url: https://freesound.org/s/276163/
    * license: Attribution 4.0
  * 276162__littlerobotsoundfactory__coins_few_17.wav.wav
    * url: https://freesound.org/s/276162/
    * license: Attribution 4.0
  * 276161__littlerobotsoundfactory__coins_few_10.wav.wav
    * url: https://freesound.org/s/276161/
    * license: Attribution 4.0
  * 276160__littlerobotsoundfactory__coins_few_11.wav.wav
    * url: https://freesound.org/s/276160/
    * license: Attribution 4.0
  * 276159__littlerobotsoundfactory__coins_few_12.wav.wav
    * url: https://freesound.org/s/276159/
    * license: Attribution 4.0
  * 276158__littlerobotsoundfactory__coins_few_13.wav.wav
    * url: https://freesound.org/s/276158/
    * license: Attribution 4.0
  * 276157__littlerobotsoundfactory__coins_single_11.wav.wav
    * url: https://freesound.org/s/276157/
    * license: Attribution 4.0
  * 276156__littlerobotsoundfactory__coins_single_12.wav.wav
    * url: https://freesound.org/s/276156/
    * license: Attribution 4.0
  * 276155__littlerobotsoundfactory__coins_single_13.wav.wav
    * url: https://freesound.org/s/276155/
    * license: Attribution 4.0
  * 276154__littlerobotsoundfactory__coins_single_14.wav.wav
    * url: https://freesound.org/s/276154/
    * license: Attribution 4.0
  * 276153__littlerobotsoundfactory__coins_single_07.wav.wav
    * url: https://freesound.org/s/276153/
    * license: Attribution 4.0
  * 276152__littlerobotsoundfactory__coins_single_08.wav.wav
    * url: https://freesound.org/s/276152/
    * license: Attribution 4.0
  * 276151__littlerobotsoundfactory__coins_single_09.wav.wav
    * url: https://freesound.org/s/276151/
    * license: Attribution 4.0
  * 276150__littlerobotsoundfactory__coins_single_10.wav.wav
    * url: https://freesound.org/s/276150/
    * license: Attribution 4.0
  * 276149__littlerobotsoundfactory__coins_single_15.wav.wav
    * url: https://freesound.org/s/276149/
    * license: Attribution 4.0
  * 276148__littlerobotsoundfactory__coins_single_16.wav.wav
    * url: https://freesound.org/s/276148/
    * license: Attribution 4.0
  * 276147__littlerobotsoundfactory__coins_single_00.wav.wav
    * url: https://freesound.org/s/276147/
    * license: Attribution 4.0
  * 276146__littlerobotsoundfactory__coins_several_22.wav.wav
    * url: https://freesound.org/s/276146/
    * license: Attribution 4.0
  * 276145__littlerobotsoundfactory__coins_several_21.wav.wav
    * url: https://freesound.org/s/276145/
    * license: Attribution 4.0
  * 276144__littlerobotsoundfactory__coins_several_20.wav.wav
    * url: https://freesound.org/s/276144/
    * license: Attribution 4.0
  * 276143__littlerobotsoundfactory__coins_single_04.wav.wav
    * url: https://freesound.org/s/276143/
    * license: Attribution 4.0
  * 276142__littlerobotsoundfactory__coins_single_03.wav.wav
    * url: https://freesound.org/s/276142/
    * license: Attribution 4.0
  * 276141__littlerobotsoundfactory__coins_single_02.wav.wav
    * url: https://freesound.org/s/276141/
    * license: Attribution 4.0
  * 276140__littlerobotsoundfactory__coins_single_01.wav.wav
    * url: https://freesound.org/s/276140/
    * license: Attribution 4.0
  * 276139__littlerobotsoundfactory__coins_single_06.wav.wav
    * url: https://freesound.org/s/276139/
    * license: Attribution 4.0
  * 276138__littlerobotsoundfactory__coins_single_05.wav.wav
    * url: https://freesound.org/s/276138/
    * license: Attribution 4.0
  * 276137__littlerobotsoundfactory__coins_few_36.wav.wav
    * url: https://freesound.org/s/276137/
    * license: Attribution 4.0
  * 276136__littlerobotsoundfactory__coins_few_37.wav.wav
    * url: https://freesound.org/s/276136/
    * license: Attribution 4.0
  * 276135__littlerobotsoundfactory__coins_few_34.wav.wav
    * url: https://freesound.org/s/276135/
    * license: Attribution 4.0
  * 276134__littlerobotsoundfactory__coins_few_35.wav.wav
    * url: https://freesound.org/s/276134/
    * license: Attribution 4.0
  * 276133__littlerobotsoundfactory__coins_few_32.wav.wav
    * url: https://freesound.org/s/276133/
    * license: Attribution 4.0
  * 276132__littlerobotsoundfactory__coins_few_33.wav.wav
    * url: https://freesound.org/s/276132/
    * license: Attribution 4.0
  * 276131__littlerobotsoundfactory__coins_few_30.wav.wav
    * url: https://freesound.org/s/276131/
    * license: Attribution 4.0
  * 276130__littlerobotsoundfactory__coins_few_31.wav.wav
    * url: https://freesound.org/s/276130/
    * license: Attribution 4.0
  * 276129__littlerobotsoundfactory__coins_few_38.wav.wav
    * url: https://freesound.org/s/276129/
    * license: Attribution 4.0
  * 276128__littlerobotsoundfactory__coins_few_39.wav.wav
    * url: https://freesound.org/s/276128/
    * license: Attribution 4.0
  * 276127__littlerobotsoundfactory__coins_single_46.wav.wav
    * url: https://freesound.org/s/276127/
    * license: Attribution 4.0
  * 276126__littlerobotsoundfactory__coins_single_45.wav.wav
    * url: https://freesound.org/s/276126/
    * license: Attribution 4.0
  * 276125__littlerobotsoundfactory__coins_single_42.wav.wav
    * url: https://freesound.org/s/276125/
    * license: Attribution 4.0
  * 276124__littlerobotsoundfactory__coins_single_41.wav.wav
    * url: https://freesound.org/s/276124/
    * license: Attribution 4.0
  * 276123__littlerobotsoundfactory__coins_single_44.wav.wav
    * url: https://freesound.org/s/276123/
    * license: Attribution 4.0
  * 276122__littlerobotsoundfactory__coins_single_43.wav.wav
    * url: https://freesound.org/s/276122/
    * license: Attribution 4.0
  * 276121__littlerobotsoundfactory__coins_single_38.wav.wav
    * url: https://freesound.org/s/276121/
    * license: Attribution 4.0
  * 276120__littlerobotsoundfactory__coins_single_37.wav.wav
    * url: https://freesound.org/s/276120/
    * license: Attribution 4.0
  * 276119__littlerobotsoundfactory__coins_single_40.wav.wav
    * url: https://freesound.org/s/276119/
    * license: Attribution 4.0
  * 276118__littlerobotsoundfactory__coins_single_39.wav.wav
    * url: https://freesound.org/s/276118/
    * license: Attribution 4.0
  * 276117__littlerobotsoundfactory__coins_few_25.wav.wav
    * url: https://freesound.org/s/276117/
    * license: Attribution 4.0
  * 276116__littlerobotsoundfactory__coins_few_24.wav.wav
    * url: https://freesound.org/s/276116/
    * license: Attribution 4.0
  * 276115__littlerobotsoundfactory__coins_few_27.wav.wav
    * url: https://freesound.org/s/276115/
    * license: Attribution 4.0
  * 276114__littlerobotsoundfactory__coins_few_26.wav.wav
    * url: https://freesound.org/s/276114/
    * license: Attribution 4.0
  * 276113__littlerobotsoundfactory__coins_few_21.wav.wav
    * url: https://freesound.org/s/276113/
    * license: Attribution 4.0
  * 276112__littlerobotsoundfactory__coins_few_20.wav.wav
    * url: https://freesound.org/s/276112/
    * license: Attribution 4.0
  * 276111__littlerobotsoundfactory__coins_few_23.wav.wav
    * url: https://freesound.org/s/276111/
    * license: Attribution 4.0
  * 276110__littlerobotsoundfactory__coins_few_22.wav.wav
    * url: https://freesound.org/s/276110/
    * license: Attribution 4.0
  * 276109__littlerobotsoundfactory__coins_few_29.wav.wav
    * url: https://freesound.org/s/276109/
    * license: Attribution 4.0
  * 276108__littlerobotsoundfactory__coins_few_28.wav.wav
    * url: https://freesound.org/s/276108/
    * license: Attribution 4.0
  * 276107__littlerobotsoundfactory__coins_single_55.wav.wav
    * url: https://freesound.org/s/276107/
    * license: Attribution 4.0
  * 276106__littlerobotsoundfactory__coins_single_49.wav.wav
    * url: https://freesound.org/s/276106/
    * license: Attribution 4.0
  * 276105__littlerobotsoundfactory__coins_single_50.wav.wav
    * url: https://freesound.org/s/276105/
    * license: Attribution 4.0
  * 276104__littlerobotsoundfactory__coins_single_47.wav.wav
    * url: https://freesound.org/s/276104/
    * license: Attribution 4.0
  * 276103__littlerobotsoundfactory__coins_single_48.wav.wav
    * url: https://freesound.org/s/276103/
    * license: Attribution 4.0
  * 276102__littlerobotsoundfactory__coins_single_53.wav.wav
    * url: https://freesound.org/s/276102/
    * license: Attribution 4.0
  * 276101__littlerobotsoundfactory__coins_single_54.wav.wav
    * url: https://freesound.org/s/276101/
    * license: Attribution 4.0
  * 276100__littlerobotsoundfactory__coins_single_51.wav.wav
    * url: https://freesound.org/s/276100/
    * license: Attribution 4.0
  * 276099__littlerobotsoundfactory__coins_single_52.wav.wav
    * url: https://freesound.org/s/276099/
    * license: Attribution 4.0
  * 276098__littlerobotsoundfactory__gems_single_05.wav.wav
    * url: https://freesound.org/s/276098/
    * license: Attribution 4.0
  * 276097__littlerobotsoundfactory__gems_single_06.wav.wav
    * url: https://freesound.org/s/276097/
    * license: Attribution 4.0
  * 276096__littlerobotsoundfactory__gems_single_03.wav.wav
    * url: https://freesound.org/s/276096/
    * license: Attribution 4.0
  * 276095__littlerobotsoundfactory__gems_single_04.wav.wav
    * url: https://freesound.org/s/276095/
    * license: Attribution 4.0
  * 276094__littlerobotsoundfactory__gems_few_04.wav.wav
    * url: https://freesound.org/s/276094/
    * license: Attribution 4.0
  * 276093__littlerobotsoundfactory__gems_single_00.wav.wav
    * url: https://freesound.org/s/276093/
    * license: Attribution 4.0
  * 276092__littlerobotsoundfactory__gems_single_01.wav.wav
    * url: https://freesound.org/s/276092/
    * license: Attribution 4.0
  * 276091__littlerobotsoundfactory__gems_single_02.wav.wav
    * url: https://freesound.org/s/276091/
    * license: Attribution 4.0
  * 276090__littlerobotsoundfactory__gems_few_00.wav.wav
    * url: https://freesound.org/s/276090/
    * license: Attribution 4.0
  * 276089__littlerobotsoundfactory__gems_few_01.wav.wav
    * url: https://freesound.org/s/276089/
    * license: Attribution 4.0
  * 276088__littlerobotsoundfactory__gems_few_02.wav.wav
    * url: https://freesound.org/s/276088/
    * license: Attribution 4.0
  * 276087__littlerobotsoundfactory__gems_few_03.wav.wav
    * url: https://freesound.org/s/276087/
    * license: Attribution 4.0


